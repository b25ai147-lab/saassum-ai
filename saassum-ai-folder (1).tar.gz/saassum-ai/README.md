# SaaSsum AI

A starter Spring Boot application for summarizing and analyzing emails.

## Requirements
- Java 17+
- Maven 3.8+

## Run locally
```bash
mvn spring-boot:run
```
Then open http://localhost:8080.

## Project status
This repository contains a runnable starter UI and API scaffold. Connect an AI provider and configure Gmail OAuth credentials before using real AI analysis or Gmail integration.

Never commit API keys, OAuth client secrets, or personal email data.
