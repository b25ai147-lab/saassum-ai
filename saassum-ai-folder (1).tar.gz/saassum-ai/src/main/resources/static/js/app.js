const form = document.querySelector('#analyze-form');
const status = document.querySelector('#status');
const result = document.querySelector('#result');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = new FormData(form);
  status.textContent = 'Analyzing email…';
  result.hidden = true;
  try {
    const response = await fetch('/api/email/analyze', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({subject: data.get('subject'), sender: data.get('sender'), body: data.get('body')})
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.message || 'Unable to analyze email.');
    document.querySelector('#summary').textContent = payload.summary;
    document.querySelector('#priority').textContent = payload.priority;
    document.querySelector('#reply').textContent = payload.suggestedReply;
    result.hidden = false;
    status.textContent = 'Analysis complete.';
  } catch (error) { status.textContent = error.message || 'Something went wrong. Please try again.'; }
});
