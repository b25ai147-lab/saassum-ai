package com.saassum.ai.dto;

public record EmailMessage(String subject, String sender, String body) {}
