package com.saassum.ai.controller;

import com.saassum.ai.dto.AnalyzeRequest;
import com.saassum.ai.dto.AnalyzeResponse;
import com.saassum.ai.service.EmailAnalysisService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/email")
public class EmailController {
    private final EmailAnalysisService service;
    public EmailController(EmailAnalysisService service) { this.service = service; }
    @PostMapping("/analyze")
    public AnalyzeResponse analyze(@RequestBody AnalyzeRequest request) { return service.analyze(request); }
}
