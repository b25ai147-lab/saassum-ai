package com.saassum.ai.exception;

public class AnalysisException extends RuntimeException {
    public AnalysisException(String message) { super(message); }
}
