package com.saassum.ai.service;

import com.saassum.ai.dto.AnalyzeRequest;
import com.saassum.ai.dto.AnalyzeResponse;
import org.springframework.stereotype.Service;

/** Placeholder for integration with a real AI provider. */
@Service
public class AiEmailAnalyzer {
    private final DemoEmailAnalyzer demo;
    public AiEmailAnalyzer(DemoEmailAnalyzer demo) { this.demo = demo; }
    public AnalyzeResponse analyze(AnalyzeRequest request) { return demo.analyze(request); }
}
