package com.saassum.ai.controller;

import com.saassum.ai.dto.GmailMessageSummary;
import com.saassum.ai.service.GmailService;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/gmail")
public class GmailController {
    private final GmailService service;
    public GmailController(GmailService service) { this.service = service; }
    @GetMapping("/messages")
    public List<GmailMessageSummary> messages() { return service.listRecentMessages(); }
}
