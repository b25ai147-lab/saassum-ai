package com.saassum.ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaaSsumApplication {
    public static void main(String[] args) {
        SpringApplication.run(SaaSsumApplication.class, args);
    }
}
