package com.saassum.ai.service;

import com.saassum.ai.dto.AnalyzeRequest;
import com.saassum.ai.dto.AnalyzeResponse;
import org.springframework.stereotype.Service;

@Service
public class DemoEmailAnalyzer {
    public AnalyzeResponse analyze(AnalyzeRequest request) {
        String body = request.body() == null ? "" : request.body().trim();
        String summary = body.length() > 240 ? body.substring(0, 237) + "..." : body;
        String text = (request.subject() + " " + body).toLowerCase();
        String priority = (text.contains("urgent") || text.contains("asap") || text.contains("deadline")) ? "High" : "Normal";
        return new AnalyzeResponse(summary.isBlank() ? "No email content provided." : summary, priority,
                "Thanks for your email. I've received your message and will follow up soon.");
    }
}
