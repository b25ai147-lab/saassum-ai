package com.saassum.ai.service;

import com.saassum.ai.dto.GmailMessageSummary;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class GmailService {
    /** Gmail OAuth/API integration is intentionally not configured in this starter. */
    public List<GmailMessageSummary> listRecentMessages() { return List.of(); }
}
