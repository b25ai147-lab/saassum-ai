package com.saassum.ai.exception;

public class GmailException extends RuntimeException {
    public GmailException(String message) { super(message); }
}
