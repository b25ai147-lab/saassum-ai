package com.saassum.ai.exception;

public class InvalidInputException extends RuntimeException {
    public InvalidInputException(String message) { super(message); }
}
