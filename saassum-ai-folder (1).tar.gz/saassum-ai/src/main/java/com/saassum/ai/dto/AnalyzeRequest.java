package com.saassum.ai.dto;

public record AnalyzeRequest(String subject, String sender, String body) {}
