package com.saassum.ai.dto;

public record AnalyzeResponse(String summary, String priority, String suggestedReply) {}
