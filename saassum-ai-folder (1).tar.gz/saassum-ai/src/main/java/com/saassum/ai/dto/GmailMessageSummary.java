package com.saassum.ai.dto;

public record GmailMessageSummary(String id, String subject, String sender, String snippet) {}
