package com.saassum.ai.service;

import com.saassum.ai.dto.AnalyzeRequest;
import com.saassum.ai.dto.AnalyzeResponse;
import com.saassum.ai.exception.InvalidInputException;
import org.springframework.stereotype.Service;

@Service
public class EmailAnalysisService {
    private final AiEmailAnalyzer analyzer;
    public EmailAnalysisService(AiEmailAnalyzer analyzer) { this.analyzer = analyzer; }
    public AnalyzeResponse analyze(AnalyzeRequest request) {
        if (request == null || request.body() == null || request.body().isBlank()) {
            throw new InvalidInputException("Email body must not be empty.");
        }
        return analyzer.analyze(request);
    }
}
