package com.saassum.ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailControllerTest {
    @Test void contextLoads() {}
}
